// Write a program to check if given number is even or not
// a = 2;
// if((a%2) != 0)
// console.log('Odd')

// if((a%2) == 0){
//     console.log('Even')
// }

// // else is for rest all, avoid unnessacry execution

// if ((a%2) !=0 ){
//     console.log(' it is an odd number')
// } else if ((a%2) == 0){
//     console.log('It is an even number')
// } else {
//     console.log('neither nor odd')
// }

// Ternary

var age = 10;

(age > 12) ? ((age < 20) ? console.log('I am teen') : console.log('I am an adult')) : console.log('I am a kid');