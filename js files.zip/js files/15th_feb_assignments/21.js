//Data Types
/*
Primitive DataTypes:
    Number
    String
    Boolean
    Null
    Undefined
    Symbol
    BigInt

    Function
    Object
    Array 
    
    Function - method
    Variable-Identifier-Attributes
    parameter-argument
    
    How to check data type of any variable*/

        // var a = 10;
        // // console.log(typeof(a));
        // // console.log(typeof(0.1+0.2))
        // console.log(typeof(a+3))
        // console.log(typeof(a-3))
        // console.log(typeof(a*3))
        // console.log(typeof(a/3))
        // console.log(typeof(a%3))
        // console.log(a/0)
        // console.log(typeof(a/0))

        //String
        // var a = 'Hello'
        // var b = 'there'
        // console.log(a+b)
        // //String Literal
            var a = 'akhil'
            console.log(`'Hi'${a} 'How are you?'`);

        //Undefined
        // var b;
        // console.log(typeof(b))
        //Null

        //NAN

