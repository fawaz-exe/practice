var data = [];
data[0] = "Hai";
data[1] = "Hello";

console.log(data);
console.log(data.length);

//.push() Inserts new element(s) at the end of the array
data.push("World","Space","Mars");
data.push("Fawaz"); //FCFS
console.log(data);

//.unshift() Inserts new elements at the beginning of array

data.unshift("Jupiter","Saturn");
console.log(data);