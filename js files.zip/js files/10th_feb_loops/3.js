/*8
88
888
8888
88888
888888
8888888
88888888 */

var temp = 8;
for(var i = 1; i<=10;i++){
    console.log(temp);
    temp += "8";
}