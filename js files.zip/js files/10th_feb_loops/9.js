var data =[];
console.log(data.length);

//used in pre defined values or multi dimensional array
var arr = new Array(50);
console.log(arr.length);
// console.log(arr);

data[99] = "THS";
console.log(data.length);
console.log(data);