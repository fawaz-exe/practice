for(var table =1; table <=10; table++){
    for(var i = 1; i<=10; i++){
        console.log(table + " x " + i + ' = ' + table*i);
    }
    console.log("\n");
}