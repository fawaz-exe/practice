for(var counter = 1; counter <=100; counter = counter + 10){
console.log("Hello World",counter);
}