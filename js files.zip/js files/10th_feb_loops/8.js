var friends = [
    "Elon Musk",
    2,
    3.14,
    {
        home: "Bangalore",
        work: "Brisbane",
        remote: "Zoom Meeting"
    },
    false,
    "Mr Alien",
    [1, 2, 3, 55, 66],
    "Chandler Bing",
    "Devil"
];

console.log(friends.length);
console.log(friends[3].work);
console.log(friends[6][3]);
