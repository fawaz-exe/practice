var a = 4;
var b = 6;
// a+=5 // a = a+5
// b -=4;

a +=5
a-=3;b+=5;c=a+b
console.log(a,b,c)