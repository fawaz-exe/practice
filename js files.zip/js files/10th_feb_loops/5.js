var a=5,b=6,c=7
a+=(b+c)
b*=(c+a)
c/=(b-a)
console.log(c,b,a)