var a=2,b=6
// console.log(5**2)
// console.log(b**a)
// b**=a
// console.log(a,b)
// b>>=a
// a<<a
// b<<b
// a+=b
// console.log(b,a)

var a=2,b=6
// a+=b+a
// b-=a-b
// console.log(b,a)
console.log(b**a**a)