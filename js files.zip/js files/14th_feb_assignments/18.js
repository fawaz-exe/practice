// Scoping in JS: The visibiltiy of a variable


var abc = 100;
console.log(xyz);

// What is a block in Programing Language

{
    let abc = 100;
    console.log(abc);
}

{
    var xyz = 50;
    console.log(xyz);
}

console.log(abc);
console.log(xyz)