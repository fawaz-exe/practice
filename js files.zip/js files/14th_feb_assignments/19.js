// Conditions
/* Sequential Operation
   Conditional Operation
   Iteration Operation
   
   If Condition
   if- else condition
   if - else - if - else condition
   Nested Conditions*/

   // SUCCESS 1 - value - true
   //  FAIL   0 - Empty - Null

   //Syntax
 /*  if(conditon){
        TASK
   }*/

//    if(true){
//        console.log('Hey there')
//    }

//    if(1){
//     console.log('Hey there 2')
// }

// if('js'){
//     console.log('Hey there 3')
// }

// if(''){
//     console.log('Hey there 4')
// }

// if(' '){
//     console.log('Hey there 5')
// }
// console.log(3^4 & 4|5)
// if(3^4 & 4|5){    //3 - 011 ; 6 - 110 value - 010 = 2
//     console.log('Hey there mate')
// }

//3 - 011
//4 - 100 
//7    111   


