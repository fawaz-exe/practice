var temp = ''
for (var i = 1; i<=9; i++){
    temp += i;
    console.log(`${temp} x 8 + ${i} = ${temp * 8 + i}`);
}