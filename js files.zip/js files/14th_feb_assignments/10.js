var temp = '';
for(var i = 1; i<=15 ; i++){
    temp += i + ' ';    
    
}

console.log(temp)
