//Logical AND
var a = 10,b= 15;
// console.log(a && b);
// console.log(11 && 12 && 15 && 17);
//console.log(a||b)
// console.log(11 || 12 || 15 || 17)
// console.log(11 || 12 || 10 || 17)
// console.log(11 || 0 || 0 || 17)
// console.log(11 || '0' || 0 || 17)
// console.log(' ' || '0' || 0 || false)
// console.log('' || 0 || false || "0" || '-')   
console.log(6&&0 || 7 && '' || false && 'o')